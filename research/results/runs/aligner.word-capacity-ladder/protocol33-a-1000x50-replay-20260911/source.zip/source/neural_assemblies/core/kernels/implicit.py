"""
Custom CuPy CUDA Kernels for Assembly Calculus
===============================================

Version: 1.1.0
Author: Assembly Calculus Project
Date: 2025-11-29

Ultra-optimized kernels using:
1. Implicit random connections (no storage, computed via hash)
2. Explicit learned weights (sparse COO)
3. PyTorch top-k integration (3x faster than CuPy)
4. Pre-allocated buffers

Memory: O(learned_connections) instead of O(n^2)

WHY EVERY HASH HERE ENDS IN AC_FMIX32 (task #37, fixed 2026-07-28)
-------------------------------------------------------------------
Each kernel decides an edge by testing the low 24 bits of
    hash = (src * 2654435761u) ^ (dst * 2246822519u) ^ seed;
and those bits are close to a function of the low bits of src and dst alone.
Density comes out right; the dependence structure does not. Measured ON DEVICE
at 2048x2048, p=0.05:

    source                   density  row disp  col disp   corr(i)
    numpy Generator (ref)    0.05003     0.960     0.996  -0.00048
    raw hash                 0.05000     3.916     0.018  -0.05263
    + AC_FMIX32              0.05023     0.977     0.941   0.00031

Column dispersion 0.018 means IN-DEGREE WAS NEARLY CONSTANT -- column sums
varied by ~1.3 where Binomial says ~9.9. ``norm_init`` scales each neuron's
incoming weights by its in-degree, so the raw hash disabled that mechanism
while every density check stayed green. Rows were over-dispersed 4x and
neighbouring synapses anti-correlated, which k-WTA reads directly.

The macro is murmur3's fmix32 and is defined identically in every kernel that
hashes, matching ``_fmix32`` in cuda_engine.py and ``_seeding.mix32`` on the
CPU. All four sites here plus both in cuda_engine.py were changed together, on
purpose: fixing a subset would leave the engine and the kernels disagreeing
about which synapses exist, which is worse than a uniform bias. Verified by
comparing kernel output against the engine's _hash_bernoulli_2d for 6 source
neurons over 4096 targets -- 0 mismatched cells.

Do not "simplify" the finalizer away.
``tests/test_seeding.py::test_raw_kernel_hash_is_biased`` pins what happens
without it.

Changelog:
- 1.1.0: Added PyTorch top-k integration, FP16 support
- 1.0.0: Initial implicit connectivity implementation
"""

import cupy as cp
import time
import torch

from ...constants.default_params import CUDA_HASH_TABLE_SIZE

# Use PyTorch for fast top-k (3x faster than CuPy argpartition)
USE_TORCH_TOPK = torch.cuda.is_available()
if USE_TORCH_TOPK:
    print("Using PyTorch top-k acceleration")

# =============================================================================
# CUDA KERNEL: Implicit Random Projection
# =============================================================================
# Computes projection using hash-based connectivity - NO weight matrix stored!

implicit_projection_kernel = cp.RawKernel(r'''
#define AC_FMIX32(h) do {     (h) ^= (h) >> 16; (h) *= 0x85ebca6bu;     (h) ^= (h) >> 13; (h) *= 0xc2b2ae35u;     (h) ^= (h) >> 16; } while (0)

extern "C" __global__
void implicit_projection(
    const unsigned int* active,      // k active indices
    float* result,                   // n output activations
    const unsigned int k,            // number of active
    const unsigned int n,            // total neurons
    const unsigned int seed,         // random seed
    const float p                    // connection probability
) {
    unsigned int dst = blockIdx.x * blockDim.x + threadIdx.x;
    if (dst >= n) return;
    
    // Load active indices into shared memory (tiled for k > blockDim.x)
    extern __shared__ unsigned int s_active[];
    for (unsigned int i = threadIdx.x; i < k; i += blockDim.x) {
        s_active[i] = active[i];
    }
    __syncthreads();
    
    // Pre-compute threshold for faster comparison
    unsigned int threshold = (unsigned int)(p * 16777216.0f);
    
    // Accumulate input from active neurons using hash-based connectivity
    // Unroll loop for better performance
    float sum = 0.0f;
    
    #pragma unroll 4
    for (unsigned int i = 0; i < k; i++) {
        unsigned int src = s_active[i];
        
        // Fast hash using multiply-xor
        unsigned int hash = (src * 2654435761u) ^ (dst * 2246822519u) ^ seed;
        AC_FMIX32(hash);
        
        // Check if connection exists
        if ((hash & 0xFFFFFFu) < threshold) {
            sum += 1.0f;
        }
    }
    
    result[dst] = sum;
}
''', 'implicit_projection')

# =============================================================================
# CUDA KERNEL: Apply Learned Weight Deltas
# =============================================================================

apply_learned_kernel = cp.RawKernel(r'''
#define AC_FMIX32(h) do {     (h) ^= (h) >> 16; (h) *= 0x85ebca6bu;     (h) ^= (h) >> 13; (h) *= 0xc2b2ae35u;     (h) ^= (h) >> 16; } while (0)

extern "C" __global__
void apply_learned(
    const unsigned int* learned_src,   // Source indices of learned connections
    const unsigned int* learned_dst,   // Destination indices
    const float* learned_delta,        // Weight deltas
    const unsigned int* active,        // Currently active indices
    float* result,                     // Output to modify
    const unsigned int* d_num_learned, // Device pointer: number of learned connections
    const unsigned int k,              // Number of active neurons
    const unsigned int seed,
    const float p
) {
    // Read num_learned from device memory (L2-cached after first access)
    unsigned int num_learned = *d_num_learned;

    // Load active indices into shared memory for fast access
    extern __shared__ unsigned int s_active[];
    for (unsigned int i = threadIdx.x; i < k; i += blockDim.x) {
        s_active[i] = active[i];
    }
    __syncthreads();

    unsigned int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= num_learned) return;

    unsigned int src = learned_src[idx];
    unsigned int dst = learned_dst[idx];
    float delta = learned_delta[idx];

    // Check if source is active (shared memory scan)
    bool src_active = false;
    for (unsigned int i = 0; i < k; i++) {
        if (s_active[i] == src) {
            src_active = true;
            break;
        }
    }

    if (src_active) {
        // Check if base connection exists (same hash as implicit_projection)
        unsigned int hash = (src * 2654435761u) ^ (dst * 2246822519u) ^ seed;
        AC_FMIX32(hash);
        unsigned int threshold = (unsigned int)(p * 16777216.0f);

        if ((hash & 0xFFFFFFu) < threshold) {
            atomicAdd(&result[dst], delta);
        }
    }
}
''', 'apply_learned')

# =============================================================================
# CUDA KERNEL: Fast Radix Top-K Selection
# =============================================================================
# O(n) instead of O(n log n) - uses histogram to find threshold

find_threshold_kernel = cp.RawKernel(r'''
extern "C" __global__
void find_threshold(
    const float* values,
    unsigned int* histogram,
    const unsigned int n,
    const unsigned int num_bins,
    const float min_val,
    const float bin_width
) {
    unsigned int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= n) return;
    
    float val = values[idx];
    unsigned int bin = (unsigned int)((val - min_val) / bin_width);
    if (bin >= num_bins) bin = num_bins - 1;
    
    atomicAdd(&histogram[bin], 1);
}
''', 'find_threshold')

select_above_threshold_kernel = cp.RawKernel(r'''
extern "C" __global__
void select_above_threshold(
    const float* values,
    unsigned int* output,
    unsigned int* count,
    const unsigned int n,
    const unsigned int k,
    const float threshold
) {
    unsigned int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= n) return;
    
    if (values[idx] >= threshold) {
        unsigned int pos = atomicAdd(count, 1);
        if (pos < k) {
            output[pos] = idx;
        }
    }
}
''', 'select_above_threshold')


def fast_topk(values: cp.ndarray, k: int) -> cp.ndarray:
    """
    Fast O(n) top-k selection using radix/histogram approach.
    
    Much faster than argpartition for large n.
    """
    n = len(values)
    
    if n <= 2048:
        # For small n, use simple argpartition (faster due to overhead)
        return cp.argpartition(values, -k)[-k:]
    
    # Find min/max
    min_val = float(values.min())
    max_val = float(values.max())
    
    if max_val == min_val:
        return cp.arange(k, dtype=cp.uint32)
    
    # Build histogram
    num_bins = 256
    bin_width = (max_val - min_val) / num_bins + 1e-10
    histogram = cp.zeros(num_bins, dtype=cp.uint32)
    
    grid = (n + 255) // 256
    find_threshold_kernel(
        (grid,), (256,),
        (values, histogram, cp.uint32(n), cp.uint32(num_bins),
         cp.float32(min_val), cp.float32(bin_width))
    )
    
    # Find threshold bin (cumsum from top)
    hist_cpu = histogram.get()
    cumsum = 0
    threshold_bin = num_bins - 1
    for i in range(num_bins - 1, -1, -1):
        cumsum += hist_cpu[i]
        if cumsum >= k:
            threshold_bin = i
            break
    
    threshold = min_val + threshold_bin * bin_width
    
    # Select all values above threshold
    output = cp.zeros(k * 2, dtype=cp.uint32)  # Extra space
    count = cp.zeros(1, dtype=cp.uint32)
    
    select_above_threshold_kernel(
        (grid,), (256,),
        (values, output, count, cp.uint32(n), cp.uint32(k * 2), cp.float32(threshold))
    )
    
    # If we got fewer than k, lower threshold and try again
    actual_count = int(count[0])
    if actual_count < k:
        # Fallback to argpartition for edge cases
        return cp.argpartition(values, -k)[-k:]
    
    return output[:k]


# =============================================================================
# CUDA KERNEL: Fused Projection + Top-K
# =============================================================================
# Combines implicit projection and top-k selection in one kernel
# to minimize memory round-trips

fused_projection_topk_kernel = cp.RawKernel(r'''
#define AC_FMIX32(h) do {     (h) ^= (h) >> 16; (h) *= 0x85ebca6bu;     (h) ^= (h) >> 13; (h) *= 0xc2b2ae35u;     (h) ^= (h) >> 16; } while (0)

#include <cuda_fp16.h>

extern "C" __global__
void fused_projection_topk(
    const unsigned int* active,      // k active indices
    float* activations,              // n activations (output)
    unsigned int* top_indices,       // k top indices (output)
    float* top_values,               // k top values (output)
    const unsigned int k_in,         // number of active inputs
    const unsigned int n,            // total neurons
    const unsigned int k_out,        // number of winners to select
    const unsigned int seed,
    const float p,
    const float threshold_hint       // hint for threshold (can be 0)
) {
    // Phase 1: Compute activations (same as implicit_projection)
    unsigned int dst = blockIdx.x * blockDim.x + threadIdx.x;
    
    extern __shared__ unsigned int s_active[];
    if (threadIdx.x < k_in && threadIdx.x < 256) {
        s_active[threadIdx.x] = active[threadIdx.x];
    }
    __syncthreads();
    
    if (dst < n) {
        unsigned int threshold = (unsigned int)(p * 16777216.0f);
        float sum = 0.0f;
        
        for (unsigned int i = 0; i < k_in; i++) {
            unsigned int src = s_active[i];
            unsigned int hash = (src * 2654435761u) ^ (dst * 2246822519u) ^ seed;
        AC_FMIX32(hash);
            if ((hash & 0xFFFFFFu) < threshold) {
                sum += 1.0f;
            }
        }
        
        activations[dst] = sum;
    }
}
''', 'fused_projection_topk')


# =============================================================================
# CUDA KERNEL: Hebbian Update (Saturating)
# =============================================================================

hebbian_update_kernel = cp.RawKernel(r'''
#define AC_FMIX32(h) do {     (h) ^= (h) >> 16; (h) *= 0x85ebca6bu;     (h) ^= (h) >> 13; (h) *= 0xc2b2ae35u;     (h) ^= (h) >> 16; } while (0)

// Must match CUDA_HASH_TABLE_SIZE in src/constants/default_params.py
#define HASH_TABLE_SIZE (1 << 20)
#define HASH_MASK (HASH_TABLE_SIZE - 1)
#define HASH_EMPTY 0xFFFFFFFFu
#define MAX_PROBES 32

__device__ __forceinline__ unsigned int pair_hash(unsigned int src, unsigned int dst) {
    unsigned int h = src;
    h ^= dst + 0x9e3779b9u + (h << 6) + (h >> 2);
    return h & HASH_MASK;
}

extern "C" __global__
void hebbian_update(
    unsigned int* learned_src,
    unsigned int* learned_dst,
    float* learned_delta,
    unsigned int* num_learned,
    unsigned int* hash_table,
    const unsigned int* prev_active,
    const unsigned int* new_active,
    const unsigned int k,
    const float beta,
    const float w_max,
    const unsigned int max_learned,
    const unsigned int seed,
    const float p
) {
    // Each thread handles one (prev, new) pair
    unsigned int pair_idx = blockIdx.x * blockDim.x + threadIdx.x;
    unsigned int i = pair_idx / k;
    unsigned int j = pair_idx % k;

    if (i >= k) return;

    unsigned int src = prev_active[i];
    unsigned int dst = new_active[j];

    // Check if base connection exists (same hash as implicit_projection)
    unsigned int hash = (src * 2654435761u) ^ (dst * 2246822519u) ^ seed;
        AC_FMIX32(hash);
    unsigned int threshold = (unsigned int)(p * 16777216.0f);

    if ((hash & 0xFFFFFFu) >= threshold) return;  // No connection to update

    // Hash table lookup with linear probing
    unsigned int h = pair_hash(src, dst);
    unsigned int found_idx = HASH_EMPTY;

    for (unsigned int probe = 0; probe < MAX_PROBES; probe++) {
        unsigned int slot = (h + probe) & HASH_MASK;
        unsigned int idx = hash_table[slot];

        if (idx == HASH_EMPTY) {
            // Empty slot - try to claim it
            unsigned int new_idx = atomicAdd(num_learned, 1);
            if (new_idx >= max_learned) {
                atomicSub(num_learned, 1);
                return;  // Table full
            }

            // Try to claim the slot
            unsigned int old = atomicCAS(&hash_table[slot], HASH_EMPTY, new_idx);
            if (old == HASH_EMPTY) {
                // Successfully claimed - initialize
                learned_src[new_idx] = src;
                learned_dst[new_idx] = dst;
                learned_delta[new_idx] = beta;
                return;
            }
            // Someone else claimed it first - undo our counter bump
            // and check if it's our pair
            atomicSub(num_learned, 1);
            idx = old;
        }

        // Check if this slot contains our pair
        if (learned_src[idx] == src && learned_dst[idx] == dst) {
            found_idx = idx;
            break;
        }
    }

    if (found_idx != HASH_EMPTY) {
        // Existing connection - saturating update
        float current_w = 1.0f + learned_delta[found_idx];
        float update = beta * (1.0f - current_w / w_max);
        if (update > 0) {
            atomicAdd(&learned_delta[found_idx], update);
        }
    }
}
''', 'hebbian_update')


class ImplicitAssemblyArea:
    """
    Assembly area using implicit random connectivity.
    
    Memory: O(learned_connections) instead of O(n^2)
    For n=100,000 with 100 words: ~25 MB instead of 40 GB!
    
    Optimizations:
    - FP16 activations for 6x faster top-k
    - Unsorted top-k for 1.3x speedup
    - Pre-allocated PyTorch tensor to avoid conversion overhead
    """
    
    def __init__(self, n: int, k: int, p: float = 0.05, 
                 beta: float = 0.1, w_max: float = 10.0, seed: int = 42,
                 use_fp16: bool = True):
        self.n = n
        self.k = k
        self.p = p
        self.beta = beta
        self.w_max = w_max
        self.seed = seed
        self.use_fp16 = use_fp16 and USE_TORCH_TOPK
        
        # Learned weights (COO format)
        self.max_learned = k * k * 1000  # Estimate
        self.learned_src = cp.zeros(self.max_learned, dtype=cp.uint32)
        self.learned_dst = cp.zeros(self.max_learned, dtype=cp.uint32)
        self.learned_delta = cp.zeros(self.max_learned, dtype=cp.float32)
        self.num_learned = cp.zeros(1, dtype=cp.uint32)
        # Hash table for O(1) Hebbian lookup
        self._hash_table_size = CUDA_HASH_TABLE_SIZE
        self.hash_table = cp.full(self._hash_table_size, 0xFFFFFFFF, dtype=cp.uint32)
        
        # Working memory - pre-allocate to avoid allocation overhead
        self.activations = cp.zeros(n, dtype=cp.float32)
        self.active = None
        self._winners_buffer = cp.zeros(k * 2, dtype=cp.uint32)
        self._count_buffer = cp.zeros(1, dtype=cp.uint32)
        self._histogram = cp.zeros(256, dtype=cp.uint32)
        
        # Pre-allocate PyTorch tensor for top-k (avoids conversion overhead)
        if USE_TORCH_TOPK:
            self._torch_activations = torch.zeros(n, device='cuda', 
                                                   dtype=torch.float16 if self.use_fp16 else torch.float32)
        
        # Block/grid sizes - optimized for RTX 4090
        self.block_size = 512  # Larger blocks for better occupancy
        self.grid_size = (n + self.block_size - 1) // self.block_size
    
    def project(self, input_indices: cp.ndarray, learn: bool = True) -> cp.ndarray:
        """
        Project from input indices to new winners.
        
        Args:
            input_indices: Indices of active input neurons
            learn: Whether to apply Hebbian learning
            
        Returns:
            Indices of new winners (top-k)
        """
        k_in = len(input_indices)
        
        # Clear activations (use slice assignment - faster than fill)
        self.activations[:] = 0
        
        # 1. Implicit random projection
        shared_mem = min(k_in, 256) * 4  # bytes for shared memory
        implicit_projection_kernel(
            (self.grid_size,), (self.block_size,),
            (input_indices, self.activations, 
             cp.uint32(k_in), cp.uint32(self.n), 
             cp.uint32(self.seed), cp.float32(self.p)),
            shared_mem=shared_mem
        )
        
        # 2. Apply learned weight modifications (non-blocking, device-pointer)
        max_learn_grid = (self.max_learned + self.block_size - 1) // self.block_size
        apply_learned_kernel(
            (max_learn_grid,), (self.block_size,),
            (self.learned_src, self.learned_dst, self.learned_delta,
             input_indices, self.activations,
             self.num_learned, cp.uint32(k_in),
             cp.uint32(self.seed), cp.float32(self.p)),
            shared_mem=k_in * 4,
        )
        
        # 3. Find top-k winners - use PyTorch topk with FP16 (6x faster!)
        if USE_TORCH_TOPK:
            # Copy to pre-allocated PyTorch tensor (faster than as_tensor)
            if self.use_fp16:
                # Convert to FP16 for faster top-k
                self._torch_activations.copy_(torch.as_tensor(self.activations, device='cuda'))
            else:
                self._torch_activations.copy_(torch.as_tensor(self.activations, device='cuda'))
            # sorted=False gives 1.3x speedup
            _, top_idx = torch.topk(self._torch_activations, self.k, sorted=False)
            winners = cp.asarray(top_idx)
        else:
            winners = cp.argpartition(self.activations, -self.k)[-self.k:]
        
        # 4. Hebbian update (only if learning and have previous activation)
        if learn and self.active is not None:
            update_grid = (self.k * self.k + self.block_size - 1) // self.block_size
            hebbian_update_kernel(
                (update_grid,), (self.block_size,),
                (self.learned_src, self.learned_dst, self.learned_delta,
                 self.num_learned, self.hash_table, self.active, winners,
                 cp.uint32(self.k), cp.float32(self.beta), cp.float32(self.w_max),
                 cp.uint32(self.max_learned), cp.uint32(self.seed), cp.float32(self.p))
            )
        
        self.active = winners
        return winners
    
    def memory_usage(self) -> dict:
        """Get memory usage in bytes"""
        learned = int(self.num_learned[0])
        return {
            'learned_connections': learned,
            'learned_bytes': learned * 12,  # 2 uint32 + 1 float32
            'activations_bytes': self.n * 4,
            'total_bytes': learned * 12 + self.n * 4
        }


def benchmark():
    """Benchmark the implicit assembly area"""
    print("=" * 70)
    print("CUSTOM CUDA KERNEL BENCHMARK")
    print("Implicit Random Connectivity + Learned Weights")
    print("=" * 70)
    print()
    
    for n in [10000, 100000, 1000000, 10000000]:
        k = 50
        p = 0.05
        
        print(f"n={n:,}, k={k}, p={p}")
        print("-" * 50)
        
        try:
            area = ImplicitAssemblyArea(n, k, p)
            
            # Warmup
            input_idx = cp.random.randint(0, n, k, dtype=cp.uint32)
            for _ in range(5):
                area.project(input_idx, learn=True)
            
            # Benchmark
            cp.cuda.Stream.null.synchronize()
            n_iter = 100
            start = time.perf_counter()
            for _ in range(n_iter):
                input_idx = cp.random.randint(0, n, k, dtype=cp.uint32)
                area.project(input_idx, learn=True)
                cp.cuda.Stream.null.synchronize()
            elapsed = time.perf_counter() - start
            
            time_per_iter = elapsed / n_iter * 1000
            mem = area.memory_usage()
            
            print(f"  Time: {time_per_iter:.3f} ms/projection")
            print(f"  Learned connections: {mem['learned_connections']:,}")
            print(f"  Memory: {mem['total_bytes'] / 1e6:.2f} MB")
            print(f"  Throughput: {1000/time_per_iter:.0f} projections/sec")
            
            # Compare to dense
            dense_mem = n * n * 4 / 1e9
            print(f"  (Dense would use: {dense_mem:.1f} GB)")
            print()
            
            del area
            cp.get_default_memory_pool().free_all_blocks()
            
        except Exception as e:
            print(f"  Error: {e}")
            print()


if __name__ == "__main__":
    benchmark()

